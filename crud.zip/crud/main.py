import tkinter as tk  # python 3
from tkinter import font  as tkfont  # python 3
from tkinter import messagebox


# import Tkinter as tk     # python 2
# import tkFont as tkfont  # python 2
from tkinter.ttk import Treeview


class SampleApp(tk.Tk):

    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        self.title_font = tkfont.Font(family='Helvetica', size=18, weight="bold", slant="italic")

        # the container is where we'll stack a bunch of frames
        # on top of each other, then the one we want visible
        # will be raised above the others
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (StartPage, PageOne, PageTwo, PageThree, PageFour):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame

            # put all of the pages in the same location;
            # the one on the top of the stacking order
            # will be the one that is visible.
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame("StartPage")

    def show_frame(self, page_name):
        '''Show a frame for the given page name'''
        frame = self.frames[page_name]
        frame.tkraise()


class StartPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        label = tk.Label(self, text="CRUD MSC", font=controller.title_font)
        label.pack(side="top", fill="x", pady=10)

        button1 = tk.Button(self, text="Insertar",
                            command=lambda: controller.show_frame("PageOne"))
        button2 = tk.Button(self, text="Actualizar",
                            command=lambda: controller.show_frame("PageTwo"))
        button3 = tk.Button(self, text="Eliminar",
                            command=lambda: controller.show_frame("PageThree"))
        button4 = tk.Button(self, text="Visualizar",
                            command=lambda: controller.show_frame("PageFour"))
        button5 = tk.Button(self, text="Salir del programa",
                            command=self.quit)

        button1.pack()
        button2.pack()
        button3.pack()
        button4.pack()
        button5.pack()


class PageOne(tk.Frame):

    def guardar(self, ent1, ent2, ent3):
        clav= int(ent1.get())
        nomb= str(ent2.get())
        sala= float(ent3.get())

        import pymysql
        db = pymysql.connect("127.0.0.1", "root", "", "msc")
        # cursor
        cursor = db.cursor()
        #query
        sql = "insert into Trabajadores(clave, nombre, sueldo) \
           values ('{0}','{1}','{2}')".format(clav,nomb, sala)
        try:
            cursor.execute(sql)
            db.commit()
            messagebox.showinfo("Exito", "Se guardo correctamente")
        except:
            db.rollback()
            messagebox.showwarning("¡Atención!", "No se guardo la información")
        db.close()

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        label = tk.Label(self, text="Insertar", font=controller.title_font)
        label.pack(side="top", fill="x", pady=10)

        #CREACION DE LA FILA 1
        row1 = tk.Frame(self)
        lab1 = tk.Label(row1, width=8, text="Clave" + ": ", anchor='w')
        ent1 = tk.Entry(row1) #ent.insert(0, "0")

        #POSICION DE LA ETIQUETA 1 Y CAMPO 1 EN LA FILA
        row1.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
        lab1.pack(side=tk.LEFT)
        ent1.pack(side=tk.RIGHT,expand=tk.YES,fill=tk.X)

        #CREACION DE LA FILA 2
        row2 = tk.Frame(self)
        lab2 = tk.Label(row2, width=8, text="Nombre" + ": ", anchor='w')
        ent2 = tk.Entry(row2) #ent.insert(0, "0")

        #POSICION DE LA ETIQUETA 2 Y CAMPO 2 EN LA FILA
        row2.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
        lab2.pack(side=tk.LEFT)
        ent2.pack(side=tk.RIGHT,expand=tk.YES,fill=tk.X)

        #CREACION DE LA FILA 3
        row3 = tk.Frame(self)
        lab3 = tk.Label(row3, width=8, text="Sueldo" + ": ", anchor='w')
        ent3 = tk.Entry(row3) #ent.insert(0, "0")

        #POSICION DE LA ETIQUETA 3 Y CAMPO 3 EN LA FILA
        row3.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
        lab3.pack(side=tk.LEFT)
        ent3.pack(side=tk.RIGHT,expand=tk.YES,fill=tk.X)

        #CREACION DE LA FILA 4
        row4 = tk.Frame(self)
        buttonguardar = tk.Button(self, text="Guardar",
                                  command= lambda: self.guardar(ent1, ent2, ent3))
        buttoninicio = tk.Button(self, text="Inicio",
                           command=lambda: controller.show_frame("StartPage"))

        row4.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
        buttoninicio.pack(side=tk.LEFT)
        buttonguardar.pack(side=tk.RIGHT,expand=tk.YES,fill=tk.X)


class PageTwo(tk.Frame):

    def actualizar(self, ent1, ent2, ent3):
        clav= int(ent1.get())
        nomb= str(ent2.get())
        sala= float(ent3.get())

        import pymysql
        db = pymysql.connect("127.0.0.1", "root", "", "msc")
        # cursor
        cursor = db.cursor()
        #query
        sql = "UPDATE Trabajadores SET nombre = %s, sueldo = %s  WHERE clave = %s"
        val = (nomb, sala, clav)
        try:
            cursor.execute(sql, val)
            db.commit()
            messagebox.showinfo("Exito", "Se actualizo correctamente")
        except:
            db.rollback()
            messagebox.showwarning("¡Atención!", "No se actualizo la información")
        db.close()

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        label = tk.Label(self, text="Actualizar", font=controller.title_font)
        label.pack(side="top", fill="x", pady=10)

        #CREACION DE LA FILA 1
        row1 = tk.Frame(self)
        lab1 = tk.Label(row1, width=8, text="Clave" + ": ", anchor='w')
        ent1 = tk.Entry(row1) #ent.insert(0, "0")

        #POSICION DE LA ETIQUETA 1 Y CAMPO 1 EN LA FILA
        row1.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
        lab1.pack(side=tk.LEFT)
        ent1.pack(side=tk.RIGHT,expand=tk.YES,fill=tk.X)

        #CREACION DE LA FILA 2
        row2 = tk.Frame(self)
        lab2 = tk.Label(row2, width=8, text="Nombre" + ": ", anchor='w')
        ent2 = tk.Entry(row2) #ent.insert(0, "0")

        #POSICION DE LA ETIQUETA 2 Y CAMPO 2 EN LA FILA
        row2.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
        lab2.pack(side=tk.LEFT)
        ent2.pack(side=tk.RIGHT,expand=tk.YES,fill=tk.X)

        #CREACION DE LA FILA 3
        row3 = tk.Frame(self)
        lab3 = tk.Label(row3, width=8, text="Sueldo" + ": ", anchor='w')
        ent3 = tk.Entry(row3) #ent.insert(0, "0")

        #POSICION DE LA ETIQUETA 3 Y CAMPO 3 EN LA FILA
        row3.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
        lab3.pack(side=tk.LEFT)
        ent3.pack(side=tk.RIGHT,expand=tk.YES,fill=tk.X)

        #CREACION DE LA FILA 4
        row4 = tk.Frame(self)
        buttonguardar = tk.Button(self, text="Actualizar",
                                  command= lambda: self.actualizar(ent1, ent2, ent3))
        buttoninicio = tk.Button(self, text="Inicio",
                           command=lambda: controller.show_frame("StartPage"))

        row4.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
        buttoninicio.pack(side=tk.LEFT)
        buttonguardar.pack(side=tk.RIGHT,expand=tk.YES,fill=tk.X)

class PageThree(tk.Frame):

    def eliminar(self, ent1):
        clav= int(ent1.get())

        import pymysql
        db = pymysql.connect("127.0.0.1", "root", "", "msc")
        # cursor
        cursor = db.cursor()
        #query
        sql = "DELETE FROM Trabajadores WHERE clave = %s"
        val = (clav)
        try:
            cursor.execute(sql, val)
            db.commit()
            messagebox.showinfo("Exito", "Se elimino correctamente")
        except:
            db.rollback()
            messagebox.showwarning("¡Atención!", "No se elimino la información")
        db.close()

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        label = tk.Label(self, text="Actualizar", font=controller.title_font)
        label.pack(side="top", fill="x", pady=10)

        #CREACION DE LA FILA 1
        row1 = tk.Frame(self)
        lab1 = tk.Label(row1, width=8, text="Clave" + ": ", anchor='w')
        ent1 = tk.Entry(row1) #ent.insert(0, "0")

        #POSICION DE LA ETIQUETA 1 Y CAMPO 1 EN LA FILA
        row1.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
        lab1.pack(side=tk.LEFT)
        ent1.pack(side=tk.RIGHT,expand=tk.YES,fill=tk.X)

        #CREACION DE LA FILA 4
        row4 = tk.Frame(self)
        buttonguardar = tk.Button(self, text="Eliminar",
                                  command= lambda: self.eliminar(ent1))
        buttoninicio = tk.Button(self, text="Inicio",
                           command=lambda: controller.show_frame("StartPage"))

        row4.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
        buttoninicio.pack(side=tk.LEFT)
        buttonguardar.pack(side=tk.RIGHT,expand=tk.YES,fill=tk.X)

class PageFour(tk.Frame):

    def simple_table(spacing=1):
        from fpdf import FPDF
        import pymysql
        db = pymysql.connect("127.0.0.1", "root", "", "msc")
        cursor = db.cursor()

        sql = "SELECT * FROM Trabajadores"
        cursor.execute(sql)

        pdf = FPDF()
        pdf.add_page()

        col_width = pdf.w / 4.5

        results = cursor.fetchall()
        pdf.set_font("Arial", size=18)
        pdf.cell(pdf.w, 18, txt="CRUD MSC", border=0, align="C")
        pdf.ln(24)
        pdf.set_font("Arial", size=12)
        pdf.cell(col_width, 12, txt="CLAVE", border=1)
        pdf.cell((col_width*2), 12, txt="NOMBRE", border=1)
        pdf.cell(col_width, 12, txt="SUELDO", border=1)
        pdf.ln(12)

        for row in results:
            clave = row[0]
            nombre = row[1]
            sueldo = row[2]
            pdf.cell(col_width, 12, txt=str(clave), border=1)
            pdf.cell((col_width*2), 12, txt=str(nombre), border=1)
            pdf.cell(col_width, 12, txt=str(sueldo), border=1)
            pdf.ln(12)

        db.close()
        pdf.output('reporte_crud.pdf')
        messagebox.showinfo("Exito", "PDF creado. Ubicación: carpeta raiz. Nombre: reporte_crud.pdf")

    def LoadTable(self):
        import pymysql
        db = pymysql.connect("127.0.0.1", "root", "", "msc")
        cursor = db.cursor()

        sql = "SELECT * FROM Trabajadores"

        cursor.execute(sql)

        results = cursor.fetchall()
        for row in results:
            clave = row[0]
            nombre = row[1]
            sueldo = row[2]
            row1 = tk.Frame(self)
            lab1 = tk.Label(row1, width=10, text="Clave: "+ str(clave), anchor='w')
            lab3 = tk.Label(row1, width=15, text="Sueldo: "+ str(sueldo), anchor='w')
            lab2 = tk.Label(row1, width=25, text="Nombre: " + str(nombre), anchor='w')

            # POSICION DE LA ETIQUETA 1 Y CAMPO 1 EN LA FILA
            row1.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
            lab1.pack(side=tk.LEFT)
            lab3.pack(side=tk.LEFT)
            lab2.pack(side=tk.RIGHT, expand=tk.YES,fill=tk.X)

        # disconnect from server
        db.close()

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        label = tk.Label(self, text="Visualizar", font=controller.title_font)
        label.pack(side="top", fill="x", pady=10)

        self.LoadTable()

        #CREACION DE LA FILA 4
        row4 = tk.Frame(self)
        buttoninicio = tk.Button(self, text="Inicio",
                           command=lambda: controller.show_frame("StartPage"))
        buttonimprimir = tk.Button(self, text="Imprimir",
                                   command=self.simple_table)

        row4.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
        buttoninicio.pack(side=tk.LEFT)
        buttonimprimir.pack(side=tk.RIGHT, expand=tk.YES, fill=tk.X)


if __name__ == "__main__":
    app = SampleApp()
    app.mainloop()
